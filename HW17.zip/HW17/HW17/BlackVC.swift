//
//  BlackVC.swift
//  HW17
//
//  Created by Дмитрий Цветков on 21.10.2022.
//

import UIKit

class BlackVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        print("BlackVC did load")
    }
    

    @IBAction func unwindToBlack(_ unwindSegue: UIStoryboardSegue) {
        let sourceViewController = unwindSegue.source
        // Use data from the view controller which initiated the unwind segue
    }

    @IBAction func goToGreen(_ sender: Any) {
        performSegue(withIdentifier: "green", sender: self)
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        print("BlackVC will appear")
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(true)
        print("BlackVC did disappear")
    }
    
    
}
