//
//  RedViewController.swift
//  HW17
//
//  Created by Дмитрий Цветков on 21.10.2022.
//

import UIKit

class RedViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        print("RedVC did load")
    }
    
    @IBAction func goToStart(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        print("RedVC will appear")
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(true)
        print("RedVC did disappear")
    }
    
    override func willMove(toParent parent: UIViewController?) {
        if parent == nil {
            print("destroy red")
        }
    }

    
}
