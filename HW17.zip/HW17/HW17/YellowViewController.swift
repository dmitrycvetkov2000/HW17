//
//  YellowViewController.swift
//  HW17
//
//  Created by Дмитрий Цветков on 21.10.2022.
//

import UIKit

class YellowViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        print("YellowVC did load")
    }
    
    @IBAction func goToRed(_ sender: Any) {
        performSegue(withIdentifier: "red", sender: self)
    }
    
    @IBAction func goToStart(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        print("YellowVC will appear")
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(true)
        print("YellowVC did disappear")
    }
    
    override func willMove(toParent parent: UIViewController?) {
        if parent == nil {
            print("destroy yellow")
        }
    }

    
}
