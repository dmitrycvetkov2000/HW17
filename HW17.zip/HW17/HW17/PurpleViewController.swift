//
//  PurpleViewController.swift
//  HW17
//
//  Created by Дмитрий Цветков on 21.10.2022.
//

import UIKit

class PurpleViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        print("PurpleVC did load")
    }
    

    @IBAction func GoToStart(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        print("PurpleVC will appear")
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(true)
        print("PurpleVC did disappear")
    }
    
    override func willMove(toParent parent: UIViewController?) {
        if parent == nil {
            print("destroy purple")
        }
    }
   
    
}
