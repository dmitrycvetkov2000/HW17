//
//  GreenViewController.swift
//  HW17
//
//  Created by Дмитрий Цветков on 21.10.2022.
//

import UIKit

class GreenViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        print("GreenVC did load")
    }
    

    @IBAction func goToPurple(_ sender: Any) {
        performSegue(withIdentifier: "purple", sender: self)
    }
    
    @IBAction func goToStart(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        print("GreenVC will appear")
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(true)
        print("GreenVC did disappear")
    }
    
    override func willMove(toParent parent: UIViewController?) {
        if parent == nil {
            print("destroy green")
        }
    }

    
}
